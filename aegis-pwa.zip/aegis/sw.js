/* AEGIS service worker — offline app shell + installability */
const CACHE = 'aegis-v1.2.0';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './outline-versions.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  // Always try the network first for the version manifest so update checks are current.
  if (new URL(req.url).pathname.endsWith('outline-versions.json')) {
    e.respondWith(
      fetch(req).then((resp) => {
        const copy = resp.clone();
        caches.open(CACHE).then((c) => c.put('./outline-versions.json', copy));
        return resp;
      }).catch(() => caches.match('./outline-versions.json'))
    );
    return;
  }
  e.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((resp) => {
          // cache same-origin GETs as they're fetched
          if (resp && resp.ok && new URL(req.url).origin === self.location.origin) {
            const copy = resp.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return resp;
        })
        .catch(() => {
          // offline fallback: serve the app shell for navigations
          if (req.mode === 'navigate') return caches.match('./index.html');
        });
    })
  );
});
